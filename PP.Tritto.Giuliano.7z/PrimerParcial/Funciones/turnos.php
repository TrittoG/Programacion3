<?php
include_once "./Clases/turno.php";

foreach(turno::leerArchivo("./Archivos/turnos.txt") as $value)
{
    

     $fecha  = $value["fecha"];
     $patente = $value["patente"];
     $marca= $value["marca"];
     $modelo = $value["modelo"];
     $precio = $value["precio"];
     $tipo= $value["tipo"];

    echo "FECHA: $fecha -- PATENTE: $patente -- MARCA: $marca -- MODELO: $modelo -- PRECIO: $precio -- tipo: $tipo <br>";
}
?>