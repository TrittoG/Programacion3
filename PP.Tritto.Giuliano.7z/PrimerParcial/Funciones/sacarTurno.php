<?php
include_once "./Clases/turno.php";
include_once "./Clases/vehiculo.php";

$patente = $_GET["patente"];
$fecha = $_GET["fecha"];
$tipo = $_GET["tipo"];


if(isset($_GET["patente"]) && isset($_GET["fecha"]) && isset($_GET["tipo"]))
{

    $miVehiculo = new vehiculo();
    
     $marca = null;
     $modelo = null;
     $precio = null;
     

    foreach(vehiculo::leerArchivo("./Archivos/vehiculos.txt") as $value)
    {
        if($_GET["patente"] == $value["patente"])
        {
            $marca = $value["marca"];
            $modelo = $value["modelo"];
            $precio = $value["precio"];
        }
    }

    $miTurno = new turno();
    $miTurno->similConstructor($marca,$modelo,$precio, $patente, $fecha, $tipo);

    $miTurno->guardarArchivo("./Archivos/turnos.txt");
   
}

?>