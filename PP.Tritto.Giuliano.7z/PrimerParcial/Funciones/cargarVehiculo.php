<?php
include_once "./Clases/vehiculo.php";


if(isset($_POST["patente"]) && isset($_POST["marca"]) && isset($_POST["modelo"]) && isset($_POST["precio"]))
{
    $miVehiculo = new vehiculo();
    $miVehiculo -> similConstructor($_POST["marca"], $_POST["modelo"], $_POST["precio"], $_POST["patente"]);

    $flag = true;
    foreach(vehiculo::leerArchivo("./Archivos/vehiculos.txt") as $value)
    {
        if($_POST["patente"] == $value["patente"])
        {
            $flag = false;
        }
    }
    
    if($flag == true)
    {
        $miVehiculo -> guardarArchivo("./Archivos/vehiculos.txt");
    }
   
}

?>