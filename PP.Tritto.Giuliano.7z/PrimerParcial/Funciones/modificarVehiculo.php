<?php
include_once "./Clases/vehiculo.php";
include_once "./Funciones/agregarFoto.php";

if(isset($_POST["patente"]))
{
    $patente = isset($_POST["patente"])?$_POST["patente"]:null;
    $marca = isset($_POST["marca"])?$_POST["marca"]:null;
    $modelo = isset($_POST["modelo"])?$_POST["modelo"]:null;
    $precio = isset($_POST["precio"])?$_POST["precio"]:null;
    $foto = isset($_FILES["foto"])?true:null;


    $arrayMiClase = vehiculo::leerArchivo("./Archivos/vehiculos.txt");
    $i = 0;
    foreach($arrayMiClase as $value)
    {
      
        if($value["patente"] == $patente)
        {
            if($marca == null)
                $marca = $value["marca"];
            if($modelo == null)
                $modelo = $value["modelo"];
            if($precio == null)
                $precio = $value["precio"];
           
            if($foto == true)
            {
                $foto = guardarFoto($_FILES, $_POST, $patente);
            } 
            else
            {
                $foto = $value["foto"];
            }
            
            $newClass = new vehiculo();
            $newClass -> similConstructor($marca, $modelo, $precio, $patente,$foto );
            $arrayMiClase[$i] = $newClass;
            break;
        }
        $i++;
    }
    vehiculo::guardarArray($arrayMiClase, "./Archivos/vehiculos.txt");
}


?>