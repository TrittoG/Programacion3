<?php
include_once "./Clases/vehiculo.php";

foreach(vehiculo::leerArchivo("./Archivos/vehiculos.txt") as $value)
{

    $patente = $value["patente"];
    $marca = $value["marca"];
    $foto = $value["foto"];
    $modelo = $value["modelo"];
    $precio = $value["precio"];


    echo "PATENTE: $patente -- MARCA: $marca -- MODELO: $modelo -- PRECIO: $precio -- FOTO:  <br>";
    echo $foto;
    echo"<img src= $foto> ";
}
?>