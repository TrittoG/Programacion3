<?php
include_once "./Clases/tipoServicio.php";



if($_POST["tipo"] == 10000 || $_POST["tipo"] == 20000 || $_POST["tipo"] == 50000)
{
    if(isset($_POST["nombre"]) && isset($_POST["id"]) && isset($_POST["tipo"]) && isset($_POST["precio"]) &&  isset($_POST["demora"]))
    {

        $miTipoServicio = new tipoServicio();
        $miTipoServicio -> similConstructor($_POST["nombre"], $_POST["id"], $_POST["precio"], $_POST["tipo"],$_POST["demora"]);
        $miTipoServicio -> guardarArchivo("./Archivos/tiposServicio.txt");
    }
}



?>