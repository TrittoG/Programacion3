<?php
include_once "./Clases/vehiculo.php";

if(isset($_GET["dato"]))
{
    $dato = $_GET["dato"];
}
else
{
    $dato = null;
}


$entre = false;

foreach(vehiculo::leerArchivo("./Archivos/vehiculos.txt") as $value)
{
    $patenteTxt = $value["patente"];
    $marcaTxt = $value["marca"];
    $modeloTxt = $value["modelo"];
    $precioTxt = $value["precio"];

    if(strcasecmp($patenteTxt, $dato) == 0 || strcasecmp($dato, $marcaTxt) == 0 || strcasecmp($dato, $modeloTxt) == 0)
    {
        echo "patente: $patenteTxt -- Marca: $marcaTxt -- Modelo: $modeloTxt -- Precio: $precioTxt <br>";
        $entre = true;
    }
}

if($entre == false)
{   
    echo "No Existe el valor $dato "; 
   
}
?>