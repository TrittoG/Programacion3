<?php

class turno
{

    public $fecha;
    public $patente;
    public $marca;
    public $modelo;
    public $precio;
    public $tipo;

    //simil constructor para que no de errores al guardar en SQL
    public function similConstructor($marca = null, $modelo = null, $precio = null, $patente = null, $fecha = null, $tipo = null)
    {
        $this -> marca = $marca;
        $this -> modelo = $modelo;
        $this -> precio = $precio;
        $this -> patente = $patente;
        $this -> fecha = $fecha;
        $this -> tipo = $tipo;
    } 

    //retorna un Json del objeto
    public function retornarJSon()
    {
        return json_encode($this);
    }


    //------------------------------ARCHIVOS----------------------------------------------


    //guarda el archivo en un nuevo renglon dentro de un txt
    public function guardarArchivo($path)
    {
        if($path != null)
        {
            $archivo = $path;
            $actual = $this -> retornarJSon();
            
            if(file_exists($archivo))
            {
                $archivo = fopen($path, "a");		 
            }else
            {
                $archivo = fopen($path, "w");	 
            }
            
            $renglon = $actual.="\r\n";
            
            fwrite($archivo, $renglon); 		 
            fclose($archivo);
        }
	}
	
	//lee un archivo de un txt enviado
	public static function leerArchivo($path)
    {
        $archivo = $path;
		if(file_exists($archivo))
		{
			$gestor = @fopen($archivo, "r");
			$arrayProveedores = array();
			$i = 0;
			while (($bufer = fgets($gestor, 4096)) !== false)
        	{
                $miClase = new turno();
                $miClase = json_decode($bufer, true);
        		$arrayProveedores[$i] = $miClase;
        		$i++;
           	}
           	
           	if (!feof($gestor)) 
    		{
       	 		echo "Error: fallo inesperado de fgets()\n";
            }		
            	
    		fclose($gestor);
    		return $arrayProveedores;
		}   	
    }




}

?>